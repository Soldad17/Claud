# Guia de Deploy do Sistema Híbrido de Trading v2.4 Beta no GKE

Este guia contém instruções para implantar o Sistema Híbrido de Trading v2.4 Beta em um cluster Google Kubernetes Engine (GKE) otimizado para recursos limitados.

## Arquivos Incluídos

1. **deploy_gke_v2.4_beta.sh** - Script principal de deploy
2. **verificar_prereqs.sh** - Script para verificar pré-requisitos
3. **configurar_monitoramento.sh** - Script para configurar monitoramento

## Requisitos

- Conta no Google Cloud com crédito gratuito (US$ 300)
- Google Cloud SDK instalado
- Permissões para criar clusters GKE

## Instruções de Uso

### Passo 1: Verificar Pré-requisitos

Execute o script de verificação de pré-requisitos para garantir que seu ambiente está pronto:

```bash
./verificar_prereqs.sh
```

Este script verifica:
- Instalação do Google Cloud SDK
- Autenticação no Google Cloud
- Configuração do projeto
- Cotas disponíveis
- APIs necessárias

### Passo 2: Executar o Deploy

Execute o script principal de deploy:

```bash
./deploy_gke_v2.4_beta.sh
```

Este script:
1. Cria um cluster GKE otimizado (2 nós e2-medium)
2. Configura namespaces e recursos básicos
3. Implanta versões otimizadas dos componentes do sistema
4. Configura ingress para acesso externo
5. Exibe a URL de acesso ao sistema

### Passo 3: Configurar Monitoramento (Opcional)

Para configurar Prometheus e Grafana para monitoramento:

```bash
./configurar_monitoramento.sh
```

Este script:
1. Implanta Prometheus para coleta de métricas
2. Implanta Grafana para visualização
3. Configura dashboards básicos
4. Exibe URLs de acesso às ferramentas de monitoramento

## Componentes Implantados

O deploy inclui versões otimizadas dos seguintes componentes:

1. **Optimization Service** - Serviço de otimização com IA avançada
2. **Decision Logs Service** - Serviço de logs de decisão com explicabilidade
3. **Personalization Engine** - Motor de personalização baseado em IA
4. **Ecosystem Integration Hub** - Hub de integração com ecossistema externo
5. **Multi-Cloud Federation Controller** - Controlador de federação multi-cloud
6. **Edge Computing Controller** - Controlador de edge computing
7. **Investor UI** - Interface do usuário para investidores

## Observações Importantes

- Esta é uma versão otimizada para recursos limitados do GKE gratuito
- Para um ambiente de produção completo, recomenda-se usar máquinas maiores
- Os requisitos de CPU e memória foram reduzidos para funcionar em um cluster pequeno
- Alguns componentes foram simplificados para economizar recursos

## Limpeza do Ambiente

Para remover todos os recursos criados:

```bash
gcloud container clusters delete [NOME-DO-CLUSTER] --zone [ZONA]
```

## Solução de Problemas

- Para verificar logs: `kubectl logs -f deployment/[nome-do-deployment] -n trading-system`
- Para reiniciar um componente: `kubectl rollout restart deployment/[nome-do-deployment] -n trading-system`
- Para escalar um componente: `kubectl scale deployment/[nome-do-deployment] --replicas=[número] -n trading-system`
