#!/bin/bash

# Script de Verificação de Pré-requisitos - Sistema Híbrido de Trading v2.4 Beta
# Este script verifica se o ambiente está pronto para o deploy

set -e

echo "=== Verificação de Pré-requisitos - Sistema Híbrido de Trading v2.4 Beta ==="

# Verificar Google Cloud SDK
if ! command -v gcloud &> /dev/null; then
    echo "❌ Google Cloud SDK não encontrado."
    echo "   Por favor, instale-o: https://cloud.google.com/sdk/docs/install"
    exit 1
else
    GCLOUD_VERSION=$(gcloud --version | head -n 1)
    echo "✅ Google Cloud SDK encontrado: $GCLOUD_VERSION"
fi

# Verificar kubectl
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl não encontrado."
    echo "   Será instalado automaticamente durante o deploy."
else
    KUBECTL_VERSION=$(kubectl version --client --short)
    echo "✅ kubectl encontrado: $KUBECTL_VERSION"
fi

# Verificar autenticação no Google Cloud
ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null)
if [ -z "$ACCOUNT" ]; then
    echo "❌ Você não está autenticado no Google Cloud."
    echo "   Execute 'gcloud auth login' antes de continuar."
    exit 1
else
    echo "✅ Autenticado no Google Cloud como: $ACCOUNT"
fi

# Verificar projeto atual
PROJECT=$(gcloud config get-value project 2>/dev/null)
if [ -z "$PROJECT" ] || [ "$PROJECT" = "(unset)" ]; then
    echo "❌ Nenhum projeto Google Cloud configurado."
    echo "   Execute 'gcloud config set project SEU_PROJETO_ID' antes de continuar."
    exit 1
else
    echo "✅ Projeto Google Cloud configurado: $PROJECT"
    
    # Verificar se o projeto existe e está acessível
    if ! gcloud projects describe $PROJECT &>/dev/null; then
        echo "❌ Não foi possível acessar o projeto $PROJECT."
        echo "   Verifique se o projeto existe e se você tem permissões adequadas."
        exit 1
    fi
fi

# Verificar cotas do Google Cloud
echo "Verificando cotas do Google Cloud..."
REGION="us-central1"
QUOTA_OK=true

# Verificar cota de CPUs
CPU_QUOTA=$(gcloud compute regions describe $REGION --format="value(quotas.metric=='CPUS'.limit)")
if (( $(echo "$CPU_QUOTA < 4" | bc -l) )); then
    echo "⚠️ Cota de CPUs pode ser insuficiente: $CPU_QUOTA"
    QUOTA_OK=false
else
    echo "✅ Cota de CPUs suficiente: $CPU_QUOTA"
fi

# Verificar cota de IPs externos
IP_QUOTA=$(gcloud compute regions describe $REGION --format="value(quotas.metric=='EXTERNAL_IN_USE_ADDRESSES'.limit)")
if (( $(echo "$IP_QUOTA < 1" | bc -l) )); then
    echo "⚠️ Cota de IPs externos pode ser insuficiente: $IP_QUOTA"
    QUOTA_OK=false
else
    echo "✅ Cota de IPs externos suficiente: $IP_QUOTA"
fi

if [ "$QUOTA_OK" = false ]; then
    echo "⚠️ Algumas cotas podem ser insuficientes. O deploy pode falhar."
    echo "   Considere solicitar aumento de cotas em: https://console.cloud.google.com/iam-admin/quotas"
fi

# Verificar APIs habilitadas
echo "Verificando APIs necessárias..."
CONTAINER_API_ENABLED=$(gcloud services list --filter="name:container.googleapis.com" --format="value(NAME)" 2>/dev/null)
if [ -z "$CONTAINER_API_ENABLED" ]; then
    echo "❌ API Kubernetes Engine não está habilitada."
    echo "   Será habilitada automaticamente durante o deploy."
else
    echo "✅ API Kubernetes Engine já está habilitada."
fi

# Verificar espaço em disco
DISK_SPACE=$(df -h . | awk 'NR==2 {print $4}')
echo "✅ Espaço em disco disponível: $DISK_SPACE"

echo ""
echo "=== Resumo da Verificação ==="
if [ "$QUOTA_OK" = true ] && [ ! -z "$CONTAINER_API_ENABLED" ]; then
    echo "✅ Ambiente pronto para deploy!"
    echo "   Execute ./deploy_gke_v2.4_beta.sh para iniciar o deploy."
else
    echo "⚠️ Ambiente parcialmente pronto."
    echo "   Você pode prosseguir com o deploy, mas algumas configurações serão feitas automaticamente."
    echo "   Execute ./deploy_gke_v2.4_beta.sh para iniciar o deploy."
fi
echo ""
