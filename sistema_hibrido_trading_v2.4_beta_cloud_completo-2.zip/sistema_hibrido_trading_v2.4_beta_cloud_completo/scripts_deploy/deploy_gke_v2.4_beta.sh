#!/bin/bash

# Script de Deploy Otimizado - Sistema Híbrido de Trading v2.4 Beta (Mini-cluster GKE Gratuito)
# Este script configura uma versão otimizada do sistema para funcionar em um cluster GKE gratuito
# com recursos limitados (2 nós e2-micro)

set -e

echo "=== Sistema Híbrido de Trading v2.4 Beta - Deploy Otimizado para GKE ==="
echo "Este script configura uma versão otimizada para recursos limitados"

# === Pré-requisitos ===
if ! command -v gcloud &> /dev/null; then
    echo "Google Cloud SDK não encontrado. Por favor, instale-o primeiro."
    echo "Visite: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

if ! command -v kubectl &> /dev/null; then
    echo "kubectl não encontrado. Instalando..."
    gcloud components install kubectl
fi

# Solicitar ID do projeto
read -p "Digite o ID do seu projeto Google Cloud: " PROJECT_ID
if [ -z "$PROJECT_ID" ]; then
    echo "ID do projeto é obrigatório."
    exit 1
fi

# Configurar projeto
echo "Configurando projeto: $PROJECT_ID"
gcloud config set project $PROJECT_ID

# Verificar autenticação
echo "Verificando autenticação..."
ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)")
if [ -z "$ACCOUNT" ]; then
    echo "Você não está autenticado no Google Cloud. Autenticando..."
    gcloud auth login
else
    echo "Autenticado como: $ACCOUNT"
fi

# Habilitar APIs necessárias
echo "Habilitando APIs necessárias..."
gcloud services enable container.googleapis.com

# === Etapa 1: Criar o cluster GKE otimizado ===
echo "Criando cluster GKE otimizado..."
read -p "Criar novo cluster? (s/n, padrão: s): " CREATE_CLUSTER
CREATE_CLUSTER=${CREATE_CLUSTER:-s}

if [[ $CREATE_CLUSTER == "s" ]]; then
    CLUSTER_NAME="trading-system-v24-beta"
    ZONE="us-central1-a"
    
    gcloud container clusters create $CLUSTER_NAME \
      --zone $ZONE \
      --num-nodes=2 \
      --machine-type=e2-medium \
      --disk-size=30GB \
      --enable-ip-alias \
      --release-channel=regular \
      --no-enable-autoupgrade \
      --enable-autoscaling \
      --min-nodes=2 \
      --max-nodes=3
    
    echo "Cluster $CLUSTER_NAME criado com sucesso!"
else
    read -p "Digite o nome do cluster existente: " CLUSTER_NAME
    read -p "Digite a zona do cluster: " ZONE
    
    if [ -z "$CLUSTER_NAME" ] || [ -z "$ZONE" ]; then
        echo "Nome do cluster e zona são obrigatórios."
        exit 1
    fi
    
    echo "Usando cluster existente: $CLUSTER_NAME na zona $ZONE"
fi

# === Etapa 2: Conectar ao cluster ===
echo "Conectando ao cluster..."
gcloud container clusters get-credentials $CLUSTER_NAME --zone $ZONE

# === Etapa 3: Criar namespaces ===
echo "Criando namespaces..."
kubectl create namespace trading-system --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -

# === Etapa 4: Criar diretório temporário para arquivos YAML otimizados ===
TEMP_DIR=$(mktemp -d)
echo "Criando arquivos YAML otimizados em $TEMP_DIR..."

# === Etapa 5: Criar ConfigMaps e Secrets necessários ===
echo "Criando ConfigMaps e Secrets básicos..."

cat <<EOF > $TEMP_DIR/trading-system-config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: trading-system-config
  namespace: trading-system
data:
  api_gateway_url: "http://api-gateway.trading-system.svc.cluster.local"
  auth_service_url: "http://auth-service.trading-system.svc.cluster.local"
  model_registry_url: "http://model-registry.trading-system.svc.cluster.local"
  feature_store_url: "http://feature-store.trading-system.svc.cluster.local"
  market_data_service_url: "http://market-data-service.trading-system.svc.cluster.local"
  decision_logs_service_url: "http://decision-logs-service.trading-system.svc.cluster.local"
  cognitive_profile_service_url: "http://personalization-engine.trading-system.svc.cluster.local:8081"
  personalization_service_url: "http://personalization-engine.trading-system.svc.cluster.local"
  edge_data_service_url: "http://edge-computing-controller.trading-system.svc.cluster.local"
  kafka_bootstrap_servers: "kafka.trading-system.svc.cluster.local:9092"
  redis_url: "redis.trading-system.svc.cluster.local:6379"
  primary_region: "us-central1"
  edge_zones: "us-central1,us-east1,us-west1"
EOF

kubectl apply -f $TEMP_DIR/trading-system-config.yaml

# === Etapa 6: Criar versões otimizadas dos componentes principais ===

# 6.1 Optimization Service (otimizado)
cat <<EOF > $TEMP_DIR/optimization-service.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: optimization-service
  namespace: trading-system
  labels:
    app: optimization-service
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: optimization-service
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: optimization-service
        version: v2.4-beta
    spec:
      containers:
      - name: optimization-service
        image: gcr.io/$PROJECT_ID/optimization-service:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: MODEL_REGISTRY_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: model_registry_url
        - name: FEATURE_STORE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: feature_store_url
        - name: MARKET_DATA_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: market_data_service_url
        - name: DECISION_LOGS_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: decision_logs_service_url
        - name: DISTRIBUTED_TRAINING_ENABLED
          value: "false"
        - name: MULTI_AGENT_ENABLED
          value: "true"
        - name: NEURO_SYMBOLIC_ENABLED
          value: "true"
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 20
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
      - name: strategy-personalization
        image: gcr.io/$PROJECT_ID/strategy-personalization:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: COGNITIVE_PROFILE_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: cognitive_profile_service_url
---
apiVersion: v1
kind: Service
metadata:
  name: optimization-service
  namespace: trading-system
  labels:
    app: optimization-service
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: optimization-service
EOF

# 6.2 Decision Logs Service (otimizado)
cat <<EOF > $TEMP_DIR/decision-logs-service.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: decision-logs-service
  namespace: trading-system
  labels:
    app: decision-logs-service
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: decision-logs-service
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: decision-logs-service
        version: v2.4-beta
    spec:
      containers:
      - name: decision-logs-service
        image: gcr.io/$PROJECT_ID/decision-logs-service:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 300m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: KAFKA_BOOTSTRAP_SERVERS
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: kafka_bootstrap_servers
        - name: MODEL_REGISTRY_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: model_registry_url
        - name: FEATURE_STORE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: feature_store_url
        - name: NEURO_SYMBOLIC_ENABLED
          value: "true"
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 3
      - name: explainability-engine
        image: gcr.io/$PROJECT_ID/explainability-engine:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: MODEL_REGISTRY_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: model_registry_url
---
apiVersion: v1
kind: Service
metadata:
  name: decision-logs-service
  namespace: trading-system
  labels:
    app: decision-logs-service
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: decision-logs-service
EOF

# 6.3 Personalization Engine (otimizado)
cat <<EOF > $TEMP_DIR/personalization-engine.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: personalization-engine
  namespace: trading-system
  labels:
    app: personalization-engine
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: personalization-engine
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: personalization-engine
        version: v2.4-beta
    spec:
      containers:
      - name: personalization-engine
        image: gcr.io/$PROJECT_ID/personalization-engine:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 300m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: KAFKA_BOOTSTRAP_SERVERS
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: kafka_bootstrap_servers
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: redis_url
        - name: MODEL_REGISTRY_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: model_registry_url
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 3
      - name: cognitive-profile-service
        image: gcr.io/$PROJECT_ID/cognitive-profile-service:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        ports:
        - containerPort: 8081
          name: http
        env:
        - name: PYTHON_ENV
          value: "production"
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: redis_url
---
apiVersion: v1
kind: Service
metadata:
  name: personalization-engine
  namespace: trading-system
  labels:
    app: personalization-engine
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  - port: 8081
    targetPort: 8081
    protocol: TCP
    name: cognitive
  selector:
    app: personalization-engine
EOF

# 6.4 Ecosystem Integration Hub (otimizado)
cat <<EOF > $TEMP_DIR/ecosystem-integration-hub.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ecosystem-integration-hub
  namespace: trading-system
  labels:
    app: ecosystem-integration-hub
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ecosystem-integration-hub
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: ecosystem-integration-hub
        version: v2.4-beta
    spec:
      containers:
      - name: integration-hub
        image: gcr.io/$PROJECT_ID/integration-hub:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 300m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: NODE_ENV
          value: "production"
        - name: KAFKA_BOOTSTRAP_SERVERS
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: kafka_bootstrap_servers
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: redis_url
        - name: AUTH_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: auth_service_url
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 3
      - name: exchange-connectors
        image: gcr.io/$PROJECT_ID/exchange-connectors:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        env:
        - name: NODE_ENV
          value: "production"
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: redis_url
---
apiVersion: v1
kind: Service
metadata:
  name: ecosystem-integration-hub
  namespace: trading-system
  labels:
    app: ecosystem-integration-hub
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: ecosystem-integration-hub
EOF

# 6.5 Multi-Cloud Federation Controller (otimizado)
cat <<EOF > $TEMP_DIR/multi-cloud-federation-controller.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: multi-cloud-federation-controller
  namespace: trading-system
  labels:
    app: multi-cloud-federation-controller
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: multi-cloud-federation-controller
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: multi-cloud-federation-controller
        version: v2.4-beta
    spec:
      containers:
      - name: federation-controller
        image: gcr.io/$PROJECT_ID/federation-controller:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 300m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: GO_ENV
          value: "production"
        - name: CLOUD_PROVIDERS
          value: "gcp"
        - name: PRIMARY_REGION
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: primary_region
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 3
      - name: global-traffic-manager
        image: gcr.io/$PROJECT_ID/global-traffic-manager:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        env:
        - name: GO_ENV
          value: "production"
---
apiVersion: v1
kind: Service
metadata:
  name: multi-cloud-federation-controller
  namespace: trading-system
  labels:
    app: multi-cloud-federation-controller
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: multi-cloud-federation-controller
EOF

# 6.6 Edge Computing Controller (otimizado)
cat <<EOF > $TEMP_DIR/edge-computing-controller.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: edge-computing-controller
  namespace: trading-system
  labels:
    app: edge-computing-controller
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: edge-computing-controller
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: edge-computing-controller
        version: v2.4-beta
    spec:
      containers:
      - name: edge-orchestrator
        image: gcr.io/$PROJECT_ID/edge-orchestrator:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 300m
            memory: 512Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: GO_ENV
          value: "production"
        - name: EDGE_ZONES
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: edge_zones
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 3
      - name: edge-data-sync
        image: gcr.io/$PROJECT_ID/edge-data-sync:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        env:
        - name: GO_ENV
          value: "production"
        - name: SYNC_INTERVAL
          value: "60"
---
apiVersion: v1
kind: Service
metadata:
  name: edge-computing-controller
  namespace: trading-system
  labels:
    app: edge-computing-controller
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: edge-computing-controller
EOF

# 6.7 Investor UI (otimizado)
cat <<EOF > $TEMP_DIR/investor-ui.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: investor-ui
  namespace: trading-system
  labels:
    app: investor-ui
    version: v2.4-beta
spec:
  replicas: 1
  selector:
    matchLabels:
      app: investor-ui
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: investor-ui
        version: v2.4-beta
    spec:
      containers:
      - name: investor-ui
        image: gcr.io/$PROJECT_ID/investor-ui:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 128Mi
          limits:
            cpu: 200m
            memory: 256Mi
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: NODE_ENV
          value: "production"
        - name: API_GATEWAY_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: api_gateway_url
        - name: AUTH_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: auth_service_url
        - name: PERSONALIZATION_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: personalization_service_url
        - name: EDGE_ENABLED
          value: "true"
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 2
          failureThreshold: 2
      - name: ui-personalization
        image: gcr.io/$PROJECT_ID/ui-personalization:v2.4-beta
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: 50m
            memory: 64Mi
          limits:
            cpu: 100m
            memory: 128Mi
        env:
        - name: NODE_ENV
          value: "production"
        - name: COGNITIVE_PROFILE_SERVICE_URL
          valueFrom:
            configMapKeyRef:
              name: trading-system-config
              key: cognitive_profile_service_url
---
apiVersion: v1
kind: Service
metadata:
  name: investor-ui
  namespace: trading-system
  labels:
    app: investor-ui
    version: v2.4-beta
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: investor-ui
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: investor-ui-ingress
  namespace: trading-system
  annotations:
    kubernetes.io/ingress.class: "gce"
spec:
  rules:
  - http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: investor-ui
            port:
              number: 80
EOF

# === Etapa 7: Criar serviços de infraestrutura básicos ===
cat <<EOF > $TEMP_DIR/infrastructure.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: trading-system
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:6.2-alpine
        resources:
          requests:
            cpu: 50m
            memory: 64Mi
          limits:
            cpu: 100m
            memory: 128Mi
        ports:
        - containerPort: 6379
---
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: trading-system
spec:
  ports:
  - port: 6379
  selector:
    app: redis
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: kafka
  namespace: trading-system
spec:
  serviceName: "kafka"
  replicas: 1
  selector:
    matchLabels:
      app: kafka
  template:
    metadata:
      labels:
        app: kafka
    spec:
      containers:
      - name: kafka
        image: bitnami/kafka:3.3.1
        resources:
          requests:
            cpu: 200m
            memory: 512Mi
          limits:
            cpu: 500m
            memory: 1Gi
        ports:
        - containerPort: 9092
          name: kafka
        env:
        - name: KAFKA_CFG_ZOOKEEPER_CONNECT
          value: "zookeeper:2181"
        - name: KAFKA_CFG_ADVERTISED_LISTENERS
          value: "PLAINTEXT://kafka:9092"
        - name: ALLOW_PLAINTEXT_LISTENER
          value: "yes"
---
apiVersion: v1
kind: Service
metadata:
  name: kafka
  namespace: trading-system
spec:
  ports:
  - port: 9092
    name: kafka
  selector:
    app: kafka
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: zookeeper
  namespace: trading-system
spec:
  replicas: 1
  selector:
    matchLabels:
      app: zookeeper
  template:
    metadata:
      labels:
        app: zookeeper
    spec:
      containers:
      - name: zookeeper
        image: bitnami/zookeeper:3.8.0
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 200m
            memory: 512Mi
        ports:
        - containerPort: 2181
        env:
        - name: ALLOW_ANONYMOUS_LOGIN
          value: "yes"
---
apiVersion: v1
kind: Service
metadata:
  name: zookeeper
  namespace: trading-system
spec:
  ports:
  - port: 2181
  selector:
    app: zookeeper
EOF

# === Etapa 8: Aplicar os arquivos YAML ===
echo "Aplicando arquivos YAML..."

# Aplicar infraestrutura básica primeiro
kubectl apply -f $TEMP_DIR/infrastructure.yaml
echo "Aguardando infraestrutura básica iniciar..."
sleep 30

# Aplicar componentes principais
kubectl apply -f $TEMP_DIR/optimization-service.yaml
kubectl apply -f $TEMP_DIR/decision-logs-service.yaml
kubectl apply -f $TEMP_DIR/personalization-engine.yaml
kubectl apply -f $TEMP_DIR/ecosystem-integration-hub.yaml
kubectl apply -f $TEMP_DIR/multi-cloud-federation-controller.yaml
kubectl apply -f $TEMP_DIR/edge-computing-controller.yaml
kubectl apply -f $TEMP_DIR/investor-ui.yaml

# === Etapa 9: Verificar status dos pods e serviços ===
echo "Verificando status dos pods..."
kubectl get pods -n trading-system

echo "Verificando status dos serviços..."
kubectl get services -n trading-system

echo "Verificando status do Ingress..."
kubectl get ingress -n trading-system

# === Etapa 10: Obter URL de acesso ===
echo "Aguardando Ingress obter IP externo..."
INGRESS_IP=""
while [ -z "$INGRESS_IP" ]; do
  INGRESS_IP=$(kubectl get ingress investor-ui-ingress -n trading-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null)
  if [ -z "$INGRESS_IP" ]; then
    echo "Aguardando IP do Ingress... (isso pode levar alguns minutos)"
    sleep 30
  fi
done

echo ""
echo "=== Deploy Concluído com Sucesso! ==="
echo ""
echo "Sistema Híbrido de Trading v2.4 Beta está disponível em:"
echo "http://$INGRESS_IP/"
echo ""
echo "Observações importantes:"
echo "1. Esta é uma versão otimizada para recursos limitados do GKE gratuito"
echo "2. Alguns componentes foram simplificados para economizar recursos"
echo "3. Para um ambiente de produção completo, recomenda-se usar máquinas maiores"
echo "4. Para monitorar os logs: kubectl logs -f deployment/[nome-do-deployment] -n trading-system"
echo ""
echo "Para limpar o ambiente:"
echo "gcloud container clusters delete $CLUSTER_NAME --zone $ZONE"
echo ""
