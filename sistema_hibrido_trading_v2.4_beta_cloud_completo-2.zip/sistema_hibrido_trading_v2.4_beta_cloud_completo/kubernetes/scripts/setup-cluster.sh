#!/bin/bash
# Script para configuração inicial de cluster Kubernetes

# Parâmetros padrão
CLUSTER="primary"
REGION="us-east-1"
NODES_MIN=3
NODES_MAX=10
NODE_TYPE="m5.xlarge"
K8S_VERSION="1.24"
PROVIDER="aws"

# Processar argumentos
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    --cluster)
      CLUSTER="$2"
      shift
      shift
      ;;
    --region)
      REGION="$2"
      shift
      shift
      ;;
    --nodes-min)
      NODES_MIN="$2"
      shift
      shift
      ;;
    --nodes-max)
      NODES_MAX="$2"
      shift
      shift
      ;;
    --node-type)
      NODE_TYPE="$2"
      shift
      shift
      ;;
    --k8s-version)
      K8S_VERSION="$2"
      shift
      shift
      ;;
    --provider)
      PROVIDER="$2"
      shift
      shift
      ;;
    *)
      echo "Argumento desconhecido: $1"
      exit 1
      ;;
  esac
done

echo "Configurando cluster Kubernetes com os seguintes parâmetros:"
echo "Cluster: $CLUSTER"
echo "Região: $REGION"
echo "Nós (min/max): $NODES_MIN/$NODES_MAX"
echo "Tipo de nó: $NODE_TYPE"
echo "Versão Kubernetes: $K8S_VERSION"
echo "Provedor: $PROVIDER"

# Função para criar cluster na AWS (EKS)
create_eks_cluster() {
  echo "Criando cluster EKS..."
  
  # Verificar se eksctl está instalado
  if ! command -v eksctl &> /dev/null; then
    echo "eksctl não encontrado. Instalando..."
    curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
    sudo mv /tmp/eksctl /usr/local/bin
  fi
  
  # Criar cluster
  eksctl create cluster \
    --name $CLUSTER \
    --region $REGION \
    --version $K8S_VERSION \
    --nodegroup-name standard-nodes \
    --node-type $NODE_TYPE \
    --nodes-min $NODES_MIN \
    --nodes-max $NODES_MAX \
    --with-oidc \
    --managed
  
  # Configurar kubectl
  aws eks update-kubeconfig --name $CLUSTER --region $REGION
  
  # Criar node group adicional para workloads ML
  eksctl create nodegroup \
    --cluster $CLUSTER \
    --region $REGION \
    --name ml-nodes \
    --node-type p3.2xlarge \
    --nodes-min 0 \
    --nodes-max 4 \
    --labels workload=ml \
    --managed
  
  # Criar node group para dados
  eksctl create nodegroup \
    --cluster $CLUSTER \
    --region $REGION \
    --name data-nodes \
    --node-type r5.2xlarge \
    --nodes-min 3 \
    --nodes-max 6 \
    --labels workload=data \
    --managed
}

# Função para criar cluster no GCP (GKE)
create_gke_cluster() {
  echo "Criando cluster GKE..."
  
  # Verificar se gcloud está instalado
  if ! command -v gcloud &> /dev/null; then
    echo "gcloud não encontrado. Por favor, instale o Google Cloud SDK."
    exit 1
  fi
  
  # Configurar projeto e região
  PROJECT_ID=$(gcloud config get-value project)
  
  # Criar cluster
  gcloud container clusters create $CLUSTER \
    --region $REGION \
    --num-nodes $NODES_MIN \
    --min-nodes $NODES_MIN \
    --max-nodes $NODES_MAX \
    --machine-type $NODE_TYPE \
    --cluster-version $K8S_VERSION \
    --enable-autoscaling \
    --enable-ip-alias \
    --enable-autoupgrade \
    --enable-autorepair
  
  # Configurar kubectl
  gcloud container clusters get-credentials $CLUSTER --region $REGION
  
  # Criar node pool para ML
  gcloud container node-pools create ml-pool \
    --cluster $CLUSTER \
    --region $REGION \
    --machine-type n1-standard-8 \
    --accelerator type=nvidia-tesla-k80,count=1 \
    --num-nodes 0 \
    --min-nodes 0 \
    --max-nodes 4 \
    --enable-autoscaling \
    --node-labels=workload=ml
  
  # Criar node pool para dados
  gcloud container node-pools create data-pool \
    --cluster $CLUSTER \
    --region $REGION \
    --machine-type n1-highmem-8 \
    --num-nodes 3 \
    --min-nodes 3 \
    --max-nodes 6 \
    --enable-autoscaling \
    --node-labels=workload=data
}

# Função para criar cluster no Azure (AKS)
create_aks_cluster() {
  echo "Criando cluster AKS..."
  
  # Verificar se az está instalado
  if ! command -v az &> /dev/null; then
    echo "az não encontrado. Por favor, instale o Azure CLI."
    exit 1
  fi
  
  # Configurar grupo de recursos
  RESOURCE_GROUP="$CLUSTER-rg"
  az group create --name $RESOURCE_GROUP --location $REGION
  
  # Criar cluster
  az aks create \
    --resource-group $RESOURCE_GROUP \
    --name $CLUSTER \
    --node-count $NODES_MIN \
    --enable-cluster-autoscaler \
    --min-count $NODES_MIN \
    --max-count $NODES_MAX \
    --node-vm-size $NODE_TYPE \
    --kubernetes-version $K8S_VERSION \
    --enable-managed-identity \
    --enable-addons monitoring
  
  # Configurar kubectl
  az aks get-credentials --resource-group $RESOURCE_GROUP --name $CLUSTER
  
  # Criar node pool para ML
  az aks nodepool add \
    --resource-group $RESOURCE_GROUP \
    --cluster-name $CLUSTER \
    --name mlpool \
    --node-count 0 \
    --min-count 0 \
    --max-count 4 \
    --node-vm-size Standard_NC6 \
    --labels workload=ml \
    --enable-cluster-autoscaler
  
  # Criar node pool para dados
  az aks nodepool add \
    --resource-group $RESOURCE_GROUP \
    --cluster-name $CLUSTER \
    --name datapool \
    --node-count 3 \
    --min-count 3 \
    --max-count 6 \
    --node-vm-size Standard_E8s_v3 \
    --labels workload=data \
    --enable-cluster-autoscaler
}

# Criar cluster baseado no provedor
case $PROVIDER in
  aws)
    create_eks_cluster
    ;;
  gcp)
    create_gke_cluster
    ;;
  azure)
    create_aks_cluster
    ;;
  *)
    echo "Provedor não suportado: $PROVIDER"
    exit 1
    ;;
esac

# Aplicar namespaces
echo "Aplicando namespaces..."
kubectl apply -f ../namespaces/namespaces.yaml

# Configurar RBAC básico
echo "Configurando RBAC..."
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kube-system
EOF

# Configurar storage classes
echo "Configurando storage classes..."
case $PROVIDER in
  aws)
    cat <<EOF | kubectl apply -f -
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: standard
  annotations:
    storageclass.kubernetes.io/is-default-class: "true"
provisioner: kubernetes.io/aws-ebs
parameters:
  type: gp3
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: premium-ssd
provisioner: kubernetes.io/aws-ebs
parameters:
  type: io1
  iopsPerGB: "50"
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: backup
provisioner: kubernetes.io/aws-ebs
parameters:
  type: sc1
reclaimPolicy: Retain
allowVolumeExpansion: true
EOF
    ;;
  gcp)
    cat <<EOF | kubectl apply -f -
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: standard
  annotations:
    storageclass.kubernetes.io/is-default-class: "true"
provisioner: kubernetes.io/gce-pd
parameters:
  type: pd-standard
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: premium-ssd
provisioner: kubernetes.io/gce-pd
parameters:
  type: pd-ssd
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: backup
provisioner: kubernetes.io/gce-pd
parameters:
  type: pd-standard
reclaimPolicy: Retain
allowVolumeExpansion: true
EOF
    ;;
  azure)
    cat <<EOF | kubectl apply -f -
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: standard
  annotations:
    storageclass.kubernetes.io/is-default-class: "true"
provisioner: kubernetes.io/azure-disk
parameters:
  storageaccounttype: StandardSSD_LRS
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: premium-ssd
provisioner: kubernetes.io/azure-disk
parameters:
  storageaccounttype: Premium_LRS
reclaimPolicy: Delete
allowVolumeExpansion: true
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: backup
provisioner: kubernetes.io/azure-disk
parameters:
  storageaccounttype: Standard_LRS
reclaimPolicy: Retain
allowVolumeExpansion: true
EOF
    ;;
esac

echo "Cluster $CLUSTER configurado com sucesso!"
echo "Para verificar o status do cluster, execute: kubectl get nodes"
