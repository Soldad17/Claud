#!/bin/bash
# Script para instalação e configuração do Istio Service Mesh

# Parâmetros padrão
CLUSTER="primary"
ISTIO_VERSION="1.15.0"
PROFILE="default"

# Processar argumentos
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    --cluster)
      CLUSTER="$2"
      shift
      shift
      ;;
    --istio-version)
      ISTIO_VERSION="$2"
      shift
      shift
      ;;
    --profile)
      PROFILE="$2"
      shift
      shift
      ;;
    *)
      echo "Argumento desconhecido: $1"
      exit 1
      ;;
  esac
done

echo "Configurando Istio Service Mesh com os seguintes parâmetros:"
echo "Cluster: $CLUSTER"
echo "Versão Istio: $ISTIO_VERSION"
echo "Perfil: $PROFILE"

# Verificar se istioctl está instalado
if ! command -v istioctl &> /dev/null; then
  echo "istioctl não encontrado. Instalando..."
  curl -L https://istio.io/downloadIstio | ISTIO_VERSION=$ISTIO_VERSION sh -
  cd istio-$ISTIO_VERSION
  export PATH=$PWD/bin:$PATH
  cd ..
fi

# Instalar Istio com o perfil especificado
echo "Instalando Istio com perfil $PROFILE..."
istioctl install --set profile=$PROFILE -y

# Verificar instalação
kubectl get svc -n istio-system
kubectl get pods -n istio-system

# Configurar injeção automática de sidecar para namespaces
echo "Configurando injeção automática de sidecar..."
kubectl label namespace frontend istio-injection=enabled --overwrite
kubectl label namespace backend istio-injection=enabled --overwrite
kubectl label namespace ml istio-injection=enabled --overwrite
kubectl label namespace tasks istio-injection=enabled --overwrite
kubectl label namespace data istio-injection=enabled --overwrite

# Instalar addons
echo "Instalando addons do Istio..."
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-$ISTIO_VERSION/samples/addons/prometheus.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-$ISTIO_VERSION/samples/addons/grafana.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-$ISTIO_VERSION/samples/addons/jaeger.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-$ISTIO_VERSION/samples/addons/kiali.yaml

# Configurar gateway padrão
echo "Configurando gateway padrão..."
cat <<EOF | kubectl apply -f -
apiVersion: networking.istio.io/v1alpha3
kind: Gateway
metadata:
  name: trading-gateway
  namespace: istio-system
spec:
  selector:
    istio: ingressgateway
  servers:
  - port:
      number: 80
      name: http
      protocol: HTTP
    hosts:
    - "*"
  - port:
      number: 443
      name: https
      protocol: HTTPS
    hosts:
    - "*"
    tls:
      mode: SIMPLE
      credentialName: trading-tls-cert
EOF

# Configurar políticas de segurança
echo "Configurando políticas de segurança..."
cat <<EOF | kubectl apply -f -
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
  namespace: istio-system
spec:
  mtls:
    mode: STRICT
EOF

# Configurar políticas de destino padrão
echo "Configurando políticas de destino padrão..."
cat <<EOF | kubectl apply -f -
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: default
  namespace: istio-system
spec:
  host: "*.local"
  trafficPolicy:
    tls:
      mode: ISTIO_MUTUAL
    connectionPool:
      tcp:
        maxConnections: 100
      http:
        http1MaxPendingRequests: 100
        maxRequestsPerConnection: 10
    outlierDetection:
      consecutive5xxErrors: 5
      interval: 30s
      baseEjectionTime: 30s
EOF

# Configurar Virtual Services para frontend
echo "Configurando Virtual Services para frontend..."
cat <<EOF | kubectl apply -f -
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: investor-ui
  namespace: frontend
spec:
  hosts:
  - "investor.trading-system.com"
  gateways:
  - istio-system/trading-gateway
  http:
  - match:
    - uri:
        prefix: /
    route:
    - destination:
        host: investor-ui
        port:
          number: 80
---
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: admin-dashboard
  namespace: frontend
spec:
  hosts:
  - "admin.trading-system.com"
  gateways:
  - istio-system/trading-gateway
  http:
  - match:
    - uri:
        prefix: /
    route:
    - destination:
        host: admin-dashboard
        port:
          number: 80
---
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: landing-page
  namespace: frontend
spec:
  hosts:
  - "trading-system.com"
  - "www.trading-system.com"
  gateways:
  - istio-system/trading-gateway
  http:
  - match:
    - uri:
        prefix: /
    route:
    - destination:
        host: landing-page-ui
        port:
          number: 80
EOF

# Configurar Circuit Breakers
echo "Configurando Circuit Breakers..."
cat <<EOF | kubectl apply -f -
apiVersion: networking.istio.io/v1alpha3
kind: DestinationRule
metadata:
  name: ml-inference-service
  namespace: ml
spec:
  host: ml-inference-service
  trafficPolicy:
    connectionPool:
      tcp:
        maxConnections: 100
      http:
        http1MaxPendingRequests: 100
        maxRequestsPerConnection: 10
    outlierDetection:
      consecutive5xxErrors: 5
      interval: 30s
      baseEjectionTime: 30s
EOF

# Configurar Retry e Timeout
echo "Configurando Retry e Timeout..."
cat <<EOF | kubectl apply -f -
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: trading-core
  namespace: backend
spec:
  hosts:
  - trading-core
  http:
  - route:
    - destination:
        host: trading-core
    retries:
      attempts: 3
      perTryTimeout: 2s
    timeout: 10s
EOF

echo "Istio Service Mesh configurado com sucesso no cluster $CLUSTER!"
echo "Para acessar o dashboard Kiali, execute: istioctl dashboard kiali"
