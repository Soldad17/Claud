#!/bin/bash
# Script para configuração de CI/CD com ArgoCD

# Parâmetros padrão
CLUSTER="primary"
ARGOCD_VERSION="2.4.0"
GITHUB_REPO="https://github.com/your-org/trading-system-k8s.git"
GITHUB_BRANCH="main"

# Processar argumentos
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    --cluster)
      CLUSTER="$2"
      shift
      shift
      ;;
    --argocd-version)
      ARGOCD_VERSION="$2"
      shift
      shift
      ;;
    --github-repo)
      GITHUB_REPO="$2"
      shift
      shift
      ;;
    --github-branch)
      GITHUB_BRANCH="$2"
      shift
      shift
      ;;
    *)
      echo "Argumento desconhecido: $1"
      exit 1
      ;;
  esac
done

echo "Configurando CI/CD com ArgoCD com os seguintes parâmetros:"
echo "Cluster: $CLUSTER"
echo "Versão ArgoCD: $ARGOCD_VERSION"
echo "Repositório GitHub: $GITHUB_REPO"
echo "Branch: $GITHUB_BRANCH"

# Verificar se kubectl está configurado
if ! kubectl get nodes &> /dev/null; then
  echo "kubectl não está configurado corretamente. Verifique a conexão com o cluster."
  exit 1
fi

# Criar namespace para ArgoCD
echo "Criando namespace para ArgoCD..."
kubectl create namespace argocd

# Instalar ArgoCD
echo "Instalando ArgoCD..."
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/v$ARGOCD_VERSION/manifests/install.yaml

# Aguardar pods do ArgoCD estarem prontos
echo "Aguardando pods do ArgoCD estarem prontos..."
kubectl wait --for=condition=Ready pods --all -n argocd --timeout=300s

# Configurar acesso ao ArgoCD
echo "Configurando acesso ao ArgoCD..."
kubectl patch svc argocd-server -n argocd -p '{"spec": {"type": "LoadBalancer"}}'

# Obter senha inicial do ArgoCD
echo "Obtendo senha inicial do ArgoCD..."
ARGOCD_PASSWORD=$(kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d)
echo "Usuário: admin"
echo "Senha: $ARGOCD_PASSWORD"

# Instalar CLI do ArgoCD
echo "Instalando CLI do ArgoCD..."
curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/download/v$ARGOCD_VERSION/argocd-linux-amd64
chmod +x /usr/local/bin/argocd

# Obter endereço do servidor ArgoCD
ARGOCD_SERVER=$(kubectl get svc argocd-server -n argocd -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$ARGOCD_SERVER" ]; then
  ARGOCD_SERVER=$(kubectl get svc argocd-server -n argocd -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
fi
if [ -z "$ARGOCD_SERVER" ]; then
  ARGOCD_SERVER="localhost"
  echo "Não foi possível determinar o endereço do servidor ArgoCD. Usando localhost."
  echo "Para acessar o ArgoCD, execute: kubectl port-forward svc/argocd-server -n argocd 8080:443"
fi

# Login no ArgoCD
echo "Fazendo login no ArgoCD..."
argocd login --insecure --username admin --password $ARGOCD_PASSWORD $ARGOCD_SERVER

# Criar aplicações no ArgoCD
echo "Criando aplicações no ArgoCD..."

# Aplicação para ambiente de desenvolvimento
argocd app create trading-system-dev \
  --repo $GITHUB_REPO \
  --path kubernetes/overlays/dev \
  --dest-server https://kubernetes.default.svc \
  --dest-namespace default \
  --sync-policy automated \
  --auto-prune \
  --self-heal

# Aplicação para ambiente de staging
argocd app create trading-system-staging \
  --repo $GITHUB_REPO \
  --path kubernetes/overlays/staging \
  --dest-server https://kubernetes.default.svc \
  --dest-namespace default \
  --sync-policy automated \
  --auto-prune \
  --self-heal

# Aplicação para ambiente de produção (sync manual)
argocd app create trading-system-prod \
  --repo $GITHUB_REPO \
  --path kubernetes/overlays/prod \
  --dest-server https://kubernetes.default.svc \
  --dest-namespace default \
  --sync-policy none

# Configurar notificações do ArgoCD (opcional)
if [ -n "$SLACK_WEBHOOK_URL" ]; then
  echo "Configurando notificações do ArgoCD para Slack..."
  kubectl apply -n argocd -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: argocd-notifications-secret
type: Opaque
stringData:
  slack-token: "$SLACK_WEBHOOK_URL"
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-notifications-cm
data:
  service.slack: |
    token: \$slack-token
    username: ArgoCD
    icon: https://argocd-notifications.readthedocs.io/en/stable/assets/logo.png
  template.app-deployed: |
    message: |
      Application {{.app.metadata.name}} has been deployed.
      Revision: {{.app.status.sync.revision}}
  template.app-sync-failed: |
    message: |
      :exclamation: Failed to sync application {{.app.metadata.name}}.
      Sync operation: {{.app.status.operationState.operation.sync.revision}}
      Error: {{.app.status.operationState.message}}
  template.app-sync-status-unknown: |
    message: |
      :question: Application {{.app.metadata.name}} sync status is unknown.
      Details: {{.app.status.operationState.message}}
  trigger.on-deployed: |
    - when: app.status.operationState.phase in ['Succeeded'] and app.status.operationState.operation.sync
      send: [app-deployed]
  trigger.on-sync-failed: |
    - when: app.status.operationState.phase in ['Failed', 'Error']
      send: [app-sync-failed]
  trigger.on-sync-status-unknown: |
    - when: app.status.sync.status == 'Unknown'
      send: [app-sync-status-unknown]
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-notifications-cm
  labels:
    app.kubernetes.io/name: argocd-notifications
    app.kubernetes.io/part-of: argocd
data:
  subscriptions: |
    - recipients:
      - slack:trading-system-deployments
      triggers:
      - on-deployed
      - on-sync-failed
      - on-sync-status-unknown
EOF
fi

echo "CI/CD com ArgoCD configurado com sucesso no cluster $CLUSTER!"
echo "Para acessar o dashboard do ArgoCD, abra: https://$ARGOCD_SERVER"
echo "Usuário: admin, Senha: $ARGOCD_PASSWORD (recomendado alterar após o primeiro login)"
