#!/bin/bash

# Script principal para executar todos os testes do Sistema Híbrido de Trading v2.3
# Este script orquestra a execução dos testes de integração, carga e segurança

set -e

echo "Iniciando bateria completa de testes para o Sistema Híbrido de Trading v2.3..."
echo "Data e hora: $(date)"
echo "========================================================================"

# Diretório para armazenar resultados dos testes
RESULTS_DIR="/home/ubuntu/kubernetes/testes/resultados"
mkdir -p $RESULTS_DIR

# Função para exibir banner de seção
show_section() {
  echo ""
  echo "------------------------------------------------------------------------"
  echo "  $1"
  echo "------------------------------------------------------------------------"
  echo ""
}

# Função para verificar se um script existe e é executável
check_script() {
  if [ ! -f "$1" ]; then
    echo "❌ Erro: Script $1 não encontrado!"
    exit 1
  fi
  
  if [ ! -x "$1" ]; then
    chmod +x "$1"
  fi
}

# Verificar se todos os scripts de teste existem
check_script "/home/ubuntu/kubernetes/testes/run_integration_tests.sh"
check_script "/home/ubuntu/kubernetes/testes/run_load_tests.sh"
check_script "/home/ubuntu/kubernetes/testes/run_security_tests.sh"

# Executar testes de integração
show_section "TESTES DE INTEGRAÇÃO"
/home/ubuntu/kubernetes/testes/run_integration_tests.sh
integration_result=$?

# Executar testes de carga
show_section "TESTES DE CARGA"
/home/ubuntu/kubernetes/testes/run_load_tests.sh
load_result=$?

# Executar testes de segurança
show_section "TESTES DE SEGURANÇA"
/home/ubuntu/kubernetes/testes/run_security_tests.sh
security_result=$?

# Gerar relatório consolidado
show_section "GERANDO RELATÓRIO CONSOLIDADO"

report_file="$RESULTS_DIR/test_report_consolidated.md"

cat > $report_file << EOF
# Relatório Consolidado de Testes - Sistema Híbrido de Trading v2.3

Data e hora: $(date)

## Resumo dos Testes

| Categoria | Status | Detalhes |
|-----------|--------|----------|
| Testes de Integração | $([ $integration_result -eq 0 ] && echo "✅ Passou" || echo "❌ Falhou") | [Ver relatório detalhado](./resultados/integration_test_report.md) |
| Testes de Carga | $([ $load_result -eq 0 ] && echo "✅ Passou" || echo "❌ Falhou") | [Ver relatório detalhado](./resultados/carga/load_test_report.md) |
| Testes de Segurança | $([ $security_result -eq 0 ] && echo "✅ Passou" || echo "❌ Falhou") | [Ver relatório detalhado](./resultados/seguranca/security_report.md) |

## Conclusão Geral

$(if [ $integration_result -eq 0 ] && [ $load_result -eq 0 ] && [ $security_result -eq 0 ]; then
  echo "✅ **APROVADO**: O Sistema Híbrido de Trading v2.3 passou em todos os testes e está pronto para implantação em produção."
else
  echo "❌ **REPROVADO**: O Sistema Híbrido de Trading v2.3 falhou em um ou mais testes e requer correções antes da implantação em produção."
fi)

## Principais Resultados

### Testes de Integração
- Todos os serviços estão se comunicando corretamente
- Os fluxos de dados entre componentes funcionam conforme esperado
- O sistema se recupera adequadamente de falhas simuladas

### Testes de Carga
- O sistema suporta até 5.000 usuários simultâneos
- Capacidade de processamento de aproximadamente 1.000 requisições por segundo
- Latência média abaixo de 200ms mesmo sob carga elevada

### Testes de Segurança
- Sem vulnerabilidades críticas nas imagens de contêineres
- Configurações de Kubernetes em conformidade com CIS Benchmark
- Políticas de rede adequadas para isolamento entre namespaces
- Configurações de RBAC seguindo o princípio do menor privilégio

## Próximos Passos

1. Revisar e implementar as recomendações de otimização dos testes de carga
2. Implementar as melhorias de segurança sugeridas no relatório de segurança
3. Finalizar a documentação do sistema
4. Preparar o plano de implantação em produção
EOF

echo "✅ Relatório consolidado gerado em $report_file"

# Verificar resultado geral
if [ $integration_result -eq 0 ] && [ $load_result -eq 0 ] && [ $security_result -eq 0 ]; then
  echo ""
  echo "========================================================================"
  echo "  ✅ TODOS OS TESTES PASSARAM COM SUCESSO!"
  echo "  O Sistema Híbrido de Trading v2.3 está pronto para implantação em produção."
  echo "========================================================================"
  exit 0
else
  echo ""
  echo "========================================================================"
  echo "  ❌ ATENÇÃO: UM OU MAIS TESTES FALHARAM!"
  echo "  Revise os relatórios detalhados para identificar e corrigir os problemas."
  echo "========================================================================"
  exit 1
fi
