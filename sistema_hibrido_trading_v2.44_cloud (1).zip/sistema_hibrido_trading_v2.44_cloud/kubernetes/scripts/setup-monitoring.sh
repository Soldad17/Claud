#!/bin/bash
# Script para instalação e configuração do stack de monitoramento

# Parâmetros padrão
CLUSTER="primary"
PROMETHEUS_VERSION="2.37.0"
GRAFANA_VERSION="9.1.0"
LOKI_VERSION="2.6.1"
TEMPO_VERSION="1.5.0"

# Processar argumentos
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    --cluster)
      CLUSTER="$2"
      shift
      shift
      ;;
    --prometheus-version)
      PROMETHEUS_VERSION="$2"
      shift
      shift
      ;;
    --grafana-version)
      GRAFANA_VERSION="$2"
      shift
      shift
      ;;
    --loki-version)
      LOKI_VERSION="$2"
      shift
      shift
      ;;
    --tempo-version)
      TEMPO_VERSION="$2"
      shift
      shift
      ;;
    *)
      echo "Argumento desconhecido: $1"
      exit 1
      ;;
  esac
done

echo "Configurando stack de monitoramento com os seguintes parâmetros:"
echo "Cluster: $CLUSTER"
echo "Versão Prometheus: $PROMETHEUS_VERSION"
echo "Versão Grafana: $GRAFANA_VERSION"
echo "Versão Loki: $LOKI_VERSION"
echo "Versão Tempo: $TEMPO_VERSION"

# Verificar se helm está instalado
if ! command -v helm &> /dev/null; then
  echo "helm não encontrado. Instalando..."
  curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
fi

# Adicionar repositórios Helm
echo "Adicionando repositórios Helm..."
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

# Criar namespace para monitoramento se não existir
kubectl get namespace monitoring &> /dev/null || kubectl create namespace monitoring

# Instalar Prometheus Operator
echo "Instalando Prometheus Operator..."
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false \
  --set grafana.enabled=true \
  --set grafana.adminPassword=admin \
  --set alertmanager.enabled=true \
  --set nodeExporter.enabled=true \
  --set kubeStateMetrics.enabled=true \
  --version $PROMETHEUS_VERSION

# Instalar Loki
echo "Instalando Loki..."
helm install loki grafana/loki-stack \
  --namespace monitoring \
  --set grafana.enabled=false \
  --set promtail.enabled=true \
  --set loki.persistence.enabled=true \
  --set loki.persistence.size=10Gi \
  --version $LOKI_VERSION

# Instalar Tempo (Tracing)
echo "Instalando Tempo..."
helm install tempo grafana/tempo \
  --namespace monitoring \
  --set tempo.persistence.enabled=true \
  --set tempo.persistence.size=10Gi \
  --set tempo.receivers.jaeger.protocols.grpc.endpoint=0.0.0.0:14250 \
  --set tempo.receivers.jaeger.protocols.thrift_http.endpoint=0.0.0.0:14268 \
  --version $TEMPO_VERSION

# Configurar datasources no Grafana
echo "Configurando datasources no Grafana..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: grafana-datasources
  namespace: monitoring
  labels:
    grafana_datasource: "1"
data:
  datasources.yaml: |-
    apiVersion: 1
    datasources:
    - name: Prometheus
      type: prometheus
      url: http://prometheus-server.monitoring.svc.cluster.local
      access: proxy
      isDefault: true
    - name: Loki
      type: loki
      url: http://loki.monitoring.svc.cluster.local:3100
      access: proxy
    - name: Tempo
      type: tempo
      url: http://tempo.monitoring.svc.cluster.local:3100
      access: proxy
      jsonData:
        httpMethod: GET
        tracesToLogs:
          datasourceUid: loki
EOF

# Aplicar ConfigMap ao Grafana
kubectl -n monitoring rollout restart deployment prometheus-grafana

# Configurar ServiceMonitors para componentes do sistema
echo "Configurando ServiceMonitors para componentes do sistema..."

# ServiceMonitor para backend
kubectl apply -f - <<EOF
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: backend-services
  namespace: monitoring
spec:
  selector:
    matchLabels:
      component: backend
  namespaceSelector:
    matchNames:
      - backend
  endpoints:
  - port: metrics
    interval: 15s
EOF

# ServiceMonitor para ML services
kubectl apply -f - <<EOF
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: ml-services
  namespace: monitoring
spec:
  selector:
    matchLabels:
      component: ml
  namespaceSelector:
    matchNames:
      - ml
  endpoints:
  - port: metrics
    interval: 15s
EOF

# ServiceMonitor para task services
kubectl apply -f - <<EOF
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: task-services
  namespace: monitoring
spec:
  selector:
    matchLabels:
      component: tasks
  namespaceSelector:
    matchNames:
      - tasks
  endpoints:
  - port: metrics
    interval: 15s
EOF

# Configurar regras de alerta
echo "Configurando regras de alerta..."
kubectl apply -f - <<EOF
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata:
  name: trading-system-alerts
  namespace: monitoring
  labels:
    prometheus: prometheus
    role: alert-rules
spec:
  groups:
  - name: trading-system
    rules:
    - alert: HighErrorRate
      expr: sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) > 0.05
      for: 5m
      labels:
        severity: critical
      annotations:
        summary: "High error rate detected"
        description: "Error rate is above 5% for the last 5 minutes"
    
    - alert: SlowResponseTime
      expr: histogram_quantile(0.95, sum(rate(http_request_duration_seconds_bucket[5m])) by (le, service)) > 1
      for: 5m
      labels:
        severity: warning
      annotations:
        summary: "Slow response time detected"
        description: "95th percentile of response time is above 1 second for the last 5 minutes"
    
    - alert: HighCPUUsage
      expr: sum(rate(container_cpu_usage_seconds_total{namespace=~"backend|ml|tasks"}[5m])) by (pod) / sum(kube_pod_container_resource_limits_cpu_cores{namespace=~"backend|ml|tasks"}) by (pod) > 0.8
      for: 15m
      labels:
        severity: warning
      annotations:
        summary: "High CPU usage detected"
        description: "CPU usage is above 80% of the limit for the last 15 minutes"
    
    - alert: HighMemoryUsage
      expr: sum(container_memory_usage_bytes{namespace=~"backend|ml|tasks"}) by (pod) / sum(kube_pod_container_resource_limits_memory_bytes{namespace=~"backend|ml|tasks"}) by (pod) > 0.8
      for: 15m
      labels:
        severity: warning
      annotations:
        summary: "High memory usage detected"
        description: "Memory usage is above 80% of the limit for the last 15 minutes"
    
    - alert: PodCrashLooping
      expr: increase(kube_pod_container_status_restarts_total{namespace=~"backend|ml|tasks|frontend|data"}[1h]) > 5
      for: 10m
      labels:
        severity: critical
      annotations:
        summary: "Pod is crash looping"
        description: "Pod {{ \$labels.pod }} in namespace {{ \$labels.namespace }} is restarting frequently"
EOF

# Configurar dashboards Grafana
echo "Configurando dashboards Grafana..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: trading-system-dashboards
  namespace: monitoring
  labels:
    grafana_dashboard: "1"
data:
  trading-system-overview.json: |-
    {
      "annotations": {
        "list": []
      },
      "editable": true,
      "gnetId": null,
      "graphTooltip": 0,
      "id": null,
      "links": [],
      "panels": [
        {
          "datasource": "Prometheus",
          "fieldConfig": {
            "defaults": {
              "color": {
                "mode": "palette-classic"
              },
              "custom": {
                "axisLabel": "",
                "axisPlacement": "auto",
                "barAlignment": 0,
                "drawStyle": "line",
                "fillOpacity": 10,
                "gradientMode": "none",
                "hideFrom": {
                  "legend": false,
                  "tooltip": false,
                  "viz": false
                },
                "lineInterpolation": "linear",
                "lineWidth": 1,
                "pointSize": 5,
                "scaleDistribution": {
                  "type": "linear"
                },
                "showPoints": "never",
                "spanNulls": true,
                "stacking": {
                  "group": "A",
                  "mode": "none"
                },
                "thresholdsStyle": {
                  "mode": "off"
                }
              },
              "mappings": [],
              "thresholds": {
                "mode": "absolute",
                "steps": [
                  {
                    "color": "green",
                    "value": null
                  },
                  {
                    "color": "red",
                    "value": 80
                  }
                ]
              },
              "unit": "reqps"
            },
            "overrides": []
          },
          "gridPos": {
            "h": 8,
            "w": 12,
            "x": 0,
            "y": 0
          },
          "id": 1,
          "options": {
            "legend": {
              "calcs": [],
              "displayMode": "list",
              "placement": "bottom"
            },
            "tooltip": {
              "mode": "single"
            }
          },
          "title": "Request Rate",
          "type": "timeseries",
          "targets": [
            {
              "expr": "sum(rate(http_requests_total[5m])) by (service)",
              "interval": "",
              "legendFormat": "{{service}}",
              "refId": "A"
            }
          ]
        },
        {
          "datasource": "Prometheus",
          "fieldConfig": {
            "defaults": {
              "color": {
                "mode": "palette-classic"
              },
              "custom": {
                "axisLabel": "",
                "axisPlacement": "auto",
                "barAlignment": 0,
                "drawStyle": "line",
                "fillOpacity": 10,
                "gradientMode": "none",
                "hideFrom": {
                  "legend": false,
                  "tooltip": false,
                  "viz": false
                },
                "lineInterpolation": "linear",
                "lineWidth": 1,
                "pointSize": 5,
                "scaleDistribution": {
                  "type": "linear"
                },
                "showPoints": "never",
                "spanNulls": true,
                "stacking": {
                  "group": "A",
                  "mode": "none"
                },
                "thresholdsStyle": {
                  "mode": "off"
                }
              },
              "mappings": [],
              "thresholds": {
                "mode": "absolute",
                "steps": [
                  {
                    "color": "green",
                    "value": null
                  },
                  {
                    "color": "red",
                    "value": 80
                  }
                ]
              },
              "unit": "s"
            },
            "overrides": []
          },
          "gridPos": {
            "h": 8,
            "w": 12,
            "x": 12,
            "y": 0
          },
          "id": 2,
          "options": {
            "legend": {
              "calcs": [],
              "displayMode": "list",
              "placement": "bottom"
            },
            "tooltip": {
              "mode": "single"
            }
          },
          "title": "Response Time (95th Percentile)",
          "type": "timeseries",
          "targets": [
            {
              "expr": "histogram_quantile(0.95, sum(rate(http_request_duration_seconds_bucket[5m])) by (le, service))",
              "interval": "",
              "legendFormat": "{{service}}",
              "refId": "A"
            }
          ]
        }
      ],
      "refresh": "10s",
      "schemaVersion": 30,
      "style": "dark",
      "tags": ["trading-system"],
      "templating": {
        "list": []
      },
      "time": {
        "from": "now-1h",
        "to": "now"
      },
      "timepicker": {},
      "timezone": "",
      "title": "Trading System Overview",
      "uid": "trading-system-overview",
      "version": 1
    }
EOF

# Configurar alertas para Slack (opcional)
if [ -n "$SLACK_WEBHOOK_URL" ]; then
  echo "Configurando alertas para Slack..."
  kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: alertmanager-slack
  namespace: monitoring
type: Opaque
stringData:
  slack_url: "$SLACK_WEBHOOK_URL"
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: alertmanager-config
  namespace: monitoring
data:
  alertmanager.yml: |
    global:
      resolve_timeout: 5m
      slack_api_url_file: /etc/alertmanager/secrets/slack_url
    route:
      group_by: ['alertname', 'job']
      group_wait: 30s
      group_interval: 5m
      repeat_interval: 12h
      receiver: 'slack-notifications'
      routes:
      - match:
          severity: critical
        receiver: 'slack-notifications'
        continue: true
    receivers:
    - name: 'slack-notifications'
      slack_configs:
      - channel: '#alerts'
        send_resolved: true
        title: '[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}] Trading System Alert'
        text: >-
          {{ range .Alerts }}
            *Alert:* {{ .Annotations.summary }}
            *Description:* {{ .Annotations.description }}
            *Severity:* {{ .Labels.severity }}
            *Time:* {{ .StartsAt }}
          {{ end }}
EOF

  # Reiniciar Alertmanager para aplicar configuração
  kubectl -n monitoring rollout restart statefulset prometheus-alertmanager
fi

echo "Stack de monitoramento configurado com sucesso no cluster $CLUSTER!"
echo "Para acessar o Grafana, execute: kubectl port-forward -n monitoring svc/prometheus-grafana 3000:80"
echo "Usuário padrão: admin, Senha padrão: admin"
