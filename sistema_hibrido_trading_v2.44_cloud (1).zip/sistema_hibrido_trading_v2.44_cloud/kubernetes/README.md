# Infraestrutura Kubernetes para Sistema Híbrido de Trading v2.3

Este diretório contém os manifestos Kubernetes e scripts de configuração para implementar a infraestrutura cloud-native do Sistema Híbrido de Trading v2.3.

## Estrutura de Diretórios

```
kubernetes/
├── README.md                     # Este arquivo
├── clusters/                     # Configuração de clusters
│   ├── primary/                  # Cluster primário
│   └── dr/                       # Cluster de disaster recovery
├── namespaces/                   # Definições de namespaces
├── base/                         # Recursos base (kustomize)
│   ├── frontend/                 # Serviços de frontend
│   ├── backend/                  # Serviços de backend core
│   ├── ml/                       # Serviços de machine learning
│   ├── tasks/                    # Serviços de tarefas
│   ├── data/                     # Serviços de dados
│   └── monitoring/               # Serviços de monitoramento
├── overlays/                     # Overlays específicos por ambiente
│   ├── dev/                      # Ambiente de desenvolvimento
│   ├── staging/                  # Ambiente de staging
│   └── prod/                     # Ambiente de produção
└── scripts/                      # Scripts de automação
    ├── setup-cluster.sh          # Configuração inicial de cluster
    ├── setup-istio.sh            # Instalação e configuração do Istio
    ├── setup-monitoring.sh       # Instalação de stack de monitoramento
    └── setup-cicd.sh             # Configuração de pipeline CI/CD
```

## Pré-requisitos

- kubectl v1.24+
- helm v3.8+
- kustomize v4.5+
- AWS CLI v2+ (para EKS) ou equivalente para outros provedores
- istioctl v1.15+

## Configuração Inicial

1. Criar clusters Kubernetes:

```bash
./scripts/setup-cluster.sh --cluster primary --region us-east-1
./scripts/setup-cluster.sh --cluster dr --region us-west-2
```

2. Configurar service mesh (Istio):

```bash
./scripts/setup-istio.sh --cluster primary
./scripts/setup-istio.sh --cluster dr
```

3. Configurar monitoramento:

```bash
./scripts/setup-monitoring.sh --cluster primary
./scripts/setup-monitoring.sh --cluster dr
```

4. Aplicar configurações base:

```bash
kubectl apply -k overlays/dev
```

## Componentes Principais

### Namespaces

Os recursos são organizados nos seguintes namespaces:

- **frontend**: Serviços de frontend (UIs)
- **backend**: Serviços de backend core
- **ml**: Serviços de machine learning
- **tasks**: Serviços de tarefas e otimização
- **data**: Serviços de dados
- **monitoring**: Serviços de monitoramento
- **istio-system**: Componentes do Istio
- **cert-manager**: Gerenciamento de certificados

### Service Mesh

Utilizamos Istio como service mesh para:

- Gerenciamento de tráfego
- Segurança (mTLS)
- Observabilidade
- Resiliência (circuit breaking, retry, etc.)

### Monitoramento

Stack de monitoramento composta por:

- Prometheus: Coleta de métricas
- Grafana: Visualização
- Loki: Agregação de logs
- Jaeger: Tracing distribuído
- Alertmanager: Alertas

### Armazenamento

Configuração de classes de armazenamento:

- **standard**: Uso geral
- **premium-ssd**: Alta performance para bancos de dados
- **backup**: Armazenamento de baixo custo para backups

## Implementação de Microserviços

Cada microserviço é implementado com os seguintes recursos:

- Deployment/StatefulSet
- Service
- ConfigMap/Secret
- HorizontalPodAutoscaler
- PodDisruptionBudget
- NetworkPolicy

## Recuperação Automática

Mecanismos de auto-healing implementados:

- Liveness/Readiness probes
- Pod restart policies
- Cluster autoscaler
- Node problem detector
- Pod priority and preemption

## Segurança

Medidas de segurança implementadas:

- Network Policies
- RBAC
- Pod Security Policies
- Secret management
- mTLS via Istio

## Próximos Passos

Após a configuração da infraestrutura base:

1. Implementar CI/CD para deployment automatizado
2. Migrar componentes existentes para a nova arquitetura
3. Implementar novas funcionalidades
4. Realizar testes de carga e resiliência
